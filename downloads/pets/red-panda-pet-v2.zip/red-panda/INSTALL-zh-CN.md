# 小熊猫

本包包含：

- `atlas.png`：透明宠物图集，1536×2288，8 列 × 11 行，每格 192×208。
- `pet.json`：原生清单，字段为 `id`、`displayName`、`description`、`spriteVersionNumber`（2）、`spritesheetPath`（`atlas.png`）。
- `server-preflight.json`、`validation.json`：本地结构校验报告。

这是素材包，不是展示 GIF。解压本身不等于已安装。

## 路线 A：Codex 桌面 App（本地安装）

1. 解压本 ZIP，得到文件夹 `red-panda/`。
2. 把整个 `red-panda` 文件夹复制到 Codex 宠物目录，最终路径应为：
   `%USERPROFILE%\.codex\pets\red-panda\pet.json` 和 `%USERPROFILE%\.codex\pets\red-panda\atlas.png`。
3. 打开 Codex 桌面 App → Settings → Pets，点击刷新，在列表中选择 **小熊猫**。
4. 如果列表里没有，检查 `pet.json` 是否在 `red-panda` 文件夹根目录，且 `spritesheetPath` 为 `atlas.png`。

注意：本地目录只做结构检查。能否在你的 Codex 版本里正常显示和动画，以实际界面为准，本包未在所有版本上实机测试。

## 路线 B：ChatGPT 网页（暂未验证，请勿按此上传）

官方 ChatGPT 网页的宠物上传说明写的尺寸是 1536×1872。本包图集是 1536×2288（Codex 桌面 v2 规格），两者不一致。我们没有验证网页端能否接受本包，因此不提供已验证的网页上传步骤。请使用路线 A。

## 不适用的情况

- 没有自定义宠物入口的客户端，不能仅靠本包启用。
- 桌面悬浮窗仅支持 macOS 和 Windows；IDE 扩展不提供宠物。

## 版权

角色与第三方 IP 的权利不因仓库 MIT 代码许可而转移。个人参考照片、账号凭据和临时下载地址不包含在本包。见仓库 `docs/ASSET-POLICY.zh-CN.md`。
